-- AlterTable
ALTER TABLE "CustomForm" ADD COLUMN     "description" TEXT;
