-- AlterTable
ALTER TABLE "Board" ADD COLUMN     "name" TEXT NOT NULL DEFAULT '';
