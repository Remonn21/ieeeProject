-- CreateIndex
CREATE INDEX "Post_title_idx" ON "Post"("title");
