-- AlterTable
ALTER TABLE "User" ADD COLUMN     "personalEmail" TEXT NOT NULL DEFAULT '';
