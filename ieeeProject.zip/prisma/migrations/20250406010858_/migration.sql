-- DropIndex
DROP INDEX "Committee_headId_key";
