-- AlterTable
ALTER TABLE "Speaker" ALTER COLUMN "job" DROP NOT NULL;
