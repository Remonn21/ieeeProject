-- AlterTable
ALTER TABLE "Event" ADD COLUMN     "private" BOOLEAN NOT NULL DEFAULT false;
