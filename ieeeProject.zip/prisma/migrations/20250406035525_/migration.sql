-- AlterTable
ALTER TABLE "Speaker" ALTER COLUMN "bio" DROP NOT NULL;
