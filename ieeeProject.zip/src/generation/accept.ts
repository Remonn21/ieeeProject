// import { PrismaClient } from "@prisma/client";
// import QRCode from "qrcode";
// import path from "path";
// import fs from "fs/promises";
// import bcrypt from "bcryptjs";
// import slugify from "slugify";
// import { format } from "date-fns";
// import { sendEmail } from "../services/mailService";
// import { parseHtmlTemplate } from "../utils/parseHtmlTemplate";

// const prisma = new PrismaClient();

// async function main() {
//   const baseUrl = process.env.BASE_URL || "http://localhost:3000/static";

//   // Get all unaccepted registrations
//   const registrations = await prisma.eventRegistration.findMany({
//     where: {
//       status: "accepted", // or "registered" if you're using that
//     },
//     include: {
//       user: true,
//       event: {
//         select: {
//           id: true,
//           name: true,
//           location: true,
//           startDate: true,
//         },
//       },
//     },
//   });

//   for (const reg of registrations) {
//     const { user, event } = reg;

//     const filename = `qr-${slugify(user.id)}.png`;
//     const qrDir = path.join(
//       __dirname,
//       `../uploads/events/${slugify(event.name)}/registration/qr-codes`
//     );
//     const qrFilePath = path.join(qrDir, filename);
//     const qrFileUrl = `${baseUrl}/uploads/events/${slugify(event.name)}/registration/qr-codes/${filename}`;

//     await fs.mkdir(qrDir, { recursive: true });
//     await QRCode.toFile(qrFilePath, user.id, {
//       margin: 2,
//       width: 300,
//     });

//     const randomPassword = generateRandomPassword(10);
//     const hashedPassword = await bcrypt.hash(randomPassword, 12);

//     const htmlTemplatePath = path.join(__dirname, "../templates/eventConfirmation.html");
//     const htmlContent = await parseHtmlTemplate(
//       htmlTemplatePath,
//       {
//         name: `${user.firstName} ${user.lastName}`,
//         date: format(event.startDate, "MMMM d, yyyy"),
//         checkInTime: format(event.startDate, "H:mm"),
//         location: "مجمع خدمات المرأة المتكامل",
//         locationLink: "https://maps.app.goo.gl/BM5dESsVL6c7C6kd6",
//         email: "user.personalEmail",
//         password: "",
//         qrCodeBase64: qrFileUrl,
//       },
//       {
//         includeLoginBlock: false,
//       }
//     );

//     // Update both user and registration
//     await Promise.all([
//       prisma.user.update({
//         where: { id: user.id },
//         data: { password: hashedPassword },
//       }),
//       prisma.eventRegistration.update({
//         where: { id: reg.id },
//         data: {
//           status: "accepted",
//           qrcode: qrFileUrl,
//         },
//       }),
//       sendEmail({
//         to: user.personalEmail,
//         subject: "Event Registration Accepted",
//         html: htmlContent,
//       }),
//     ]);

//     console.log(`✅ Accepted + emailed: ${user.personalEmail}`);
//   }

//   console.log("🎉 All registrations processed.");
// }

// function generateRandomPassword(length: number): string {
//   const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
//   return Array.from(
//     { length },
//     () => chars[Math.floor(Math.random() * chars.length)]
//   ).join("");
// }

// main()
//   .catch((err) => {
//     console.error("❌ Error:", err);
//   })
//   .finally(() => prisma.$disconnect());
