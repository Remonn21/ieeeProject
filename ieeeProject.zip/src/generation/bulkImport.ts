// scripts/bulkImport.ts
import { PrismaClient, User } from "@prisma/client";
import xlsx from "xlsx";
import path from "path";
import { createMockRequest, createMockResponse } from "./mockExpress";
import { NextFunction } from "express";
import { registerToEvent } from "../controllers/eventRegistrationController";
import { generateRandomPassword } from "../utils";
import bcrypt from "bcryptjs";
const prisma = new PrismaClient();

function splitName(fullName: string): { firstName: string; lastName: string } {
  const parts = fullName.trim().split(" ");
  const firstName = parts[0] || "";
  const lastName = parts.slice(1).join(" ") || "Unknown";
  return { firstName, lastName };
}

async function main() {
  const filePath = path.join(__dirname, "./registrations.xlsx");
  const workbook = xlsx.readFile(filePath);
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const rows: Record<string, any>[] = xlsx.utils.sheet_to_json(sheet);

  const eventId = "c9a18efb-ef16-4475-ac9e-977ab9a58401"; // Replace with your actual event ID

  const event = await prisma.event.findUnique({ where: { id: eventId } });
  if (!event) {
    throw new Error("❌ Event not found");
  }

  for (const row of rows) {
    if (!row["Full Name"] || !row["Email"]) {
      console.warn("⚠️ Skipping row due to missing Full Name or Email:", row);
      continue;
    }

    const { firstName, lastName } = splitName(row["Full Name"]);
    const email = row["Email"].trim().toLowerCase();

    // Check if user already exists
    let user = await prisma.user.findUnique({ where: { email: email } });

    // Create user if not exists
    if (!user) {
      const randomPassword = generateRandomPassword(10);
      const hashedPassword = await bcrypt.hash(randomPassword, 12);
      user = await prisma.user.create({
        data: {
          email: email,
          phone: "",
          firstName,
          lastName,
          personalEmail: email,
          password: hashedPassword, // or set a temp password if needed
        },
      });
      console.log(`✅ Created user: ${firstName} ${lastName} (${email})`);
    } else {
      console.log(`ℹ️ User already exists: ${email}`);
    }

    // Check if already registered
    const alreadyRegistered = await prisma.eventRegistration.findFirst({
      where: {
        eventId,
        userId: user.id,
      },
    });

    if (alreadyRegistered) {
      console.log(`⚠️ Already registered: ${email}`);
      continue;
    }

    // Register to event
    await prisma.eventRegistration.create({
      data: {
        eventId,
        userId: user.id,
        status: "pending",
      },
    });

    console.log(`✅ Registered to event: ${email}`);
  }

  console.log("🎉 Import completed");
}

main()
  .catch((err) => {
    console.error("❌ Fatal error:", err);
  })
  .finally(() => prisma.$disconnect());
