// scripts/mockExpress.ts
import { Request, Response } from "express";

interface MockRequestProps {
  params?: Record<string, any>;
  body?: Record<string, any>;
  user?: any; // ← let us pass in custom user
}
import { UserWithRelations } from "../controllers/authController";

declare global {
  namespace Express {
    interface Request {
      user?: UserWithRelations;
    }
  }
}

export function createMockRequest({
  params = {},
  body = {},
  user = {},
}: MockRequestProps): Partial<Request> {
  const req: Partial<Request> = {
    params,
    body,
  };

  // @ts-ignore: user is custom-added in your app
  req.user = null;

  return req;
}

export function createMockResponse(): Partial<Response> {
  const res: Partial<Response> = {};

  res.status = (code: number): Response => {
    console.log(`HTTP ${code}`);
    return {
      ...res,
      json: (data: any) => {
        console.log("Response JSON:", JSON.stringify(data, null, 2));
        return res as Response;
      },
    } as Response;
  };

  return res;
}
