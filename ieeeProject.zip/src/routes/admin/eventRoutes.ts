import { Router } from "express";

import { authorizeRoles } from "../../middlewares/authroizeRoles";
import {
  attendUser,
  createEvent,
  createEventEssentials,
  getEventAttendanceStats,
  getEventDetails,
  getEventRegisteredUsers,
  getEvents,
} from "../../controllers/eventController";
import { createEventSchema } from "../../validations/eventValidation";
import { validate } from "../../middlewares/validate";
import {
  acceptEventRegistration,
  getRegisterResponseDetails,
} from "../../controllers/eventRegistrationController";
import {
  createFoodMenu,
  getEventFoodOrders,
  getFoodMenusForEvent,
  updateFoodMenu,
} from "../../controllers/eventFoodController";

const router = Router();
// router.use(authorizeRoles("EXCOM", "Head"));
router.get("/:id/registers", getEventRegisteredUsers);
router.get("/:eventId/attendees", getEventAttendanceStats);
router.post("/:eventId/attendees", attendUser);
router.get("/responses/:responseId", getRegisterResponseDetails);
router.get("/responses/:responseId/accept-user", acceptEventRegistration);

// food menu
router.get("/:id/food-menu", getFoodMenusForEvent);
router.post("/:id/food-menu", createFoodMenu);
router.patch("/:eventId/food-menu/:menuId", updateFoodMenu);

// food orders
router.get("/:eventId/food-orders", getEventFoodOrders);

router.use(authorizeRoles("EXCOM"));

router.get("/", getEvents);
router.post("/", validate(createEventSchema), createEvent);
router.post("/:id/essentials", createEventEssentials);
// router.patch("/:id", updateCommittee);
// router.delete("/:id", deleteCommittee);
router.get("/:id", getEventDetails);

export default router;
